See the docs directory or http://hbase.org
